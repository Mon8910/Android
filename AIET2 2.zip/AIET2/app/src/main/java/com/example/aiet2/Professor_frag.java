package com.example.aiet2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class Professor_frag extends Fragment {
    Button btn_logP;
    MainActivity mainActivity;
    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view_profFrag =inflater.inflate(R.layout.fragment_prof_frag, container, false);
        btn_logP=view_profFrag.findViewById(R.id.btn_logP);
        btn_logP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_log_p_frag);
            }
        });

        return view_profFrag;
    }


}