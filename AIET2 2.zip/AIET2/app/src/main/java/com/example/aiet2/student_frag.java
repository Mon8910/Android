package com.example.aiet2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class student_frag extends Fragment {
    Button btn_logS;
    Button btn_attS;
    MainActivity mainActivity;
    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view_stdFrag =inflater.inflate(R.layout.fragment_student_frag, container, false);
        btn_logS=  view_stdFrag.findViewById(R.id.btn_logS);
        btn_logS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              mainActivity.addFragment(R.layout.fragment_log_p_frag);
            }
        });
        return view_stdFrag;
    }
}