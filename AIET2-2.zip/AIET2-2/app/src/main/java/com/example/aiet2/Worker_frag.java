package com.example.aiet2;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class Worker_frag extends Fragment {
    Button btn_logw;
    Button btn_cpw;
    MainActivity mainActivity;
    public void setActivity(MainActivity mainActivity){
        this.mainActivity=mainActivity;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view_wokfrag =inflater.inflate(R.layout.fragment_worker_frag, container, false);
        btn_logw=view_wokfrag.findViewById(R.id.btn_logW);
        btn_logw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_login_frag);
            }
        });
        btn_cpw=view_wokfrag.findViewById(R.id.btn_cpw);
        btn_cpw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.addFragment(R.layout.fragment_qr_code);

            }
        });


        return view_wokfrag;
    }

}