package com.example.aiet2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentManager = getSupportFragmentManager();
        addFragment(R.layout.fragment_button_frag);


    }

    public void addFragment(long id) {
        if (id == R.layout.fragment_button_frag) {
            fragmentTransaction = fragmentManager.beginTransaction();
            button_frag frag_1 = new button_frag();
            frag_1.setActivity(this);
            fragmentTransaction.add(R.id.Main_layout,frag_1);
            fragmentTransaction.commit();

        }
        else if(id==R.layout.fragment_student_frag){
            fragmentTransaction = fragmentManager.beginTransaction();
            student_frag frag_2= new student_frag();
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout,frag_2);
            fragmentTransaction.commit();
        }
        else if(id==R.layout.fragment_prof_frag){
            fragmentTransaction = fragmentManager.beginTransaction();
            Professor_frag frag_3 = new Professor_frag();
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout,frag_3);
            fragmentTransaction.commit();
        }
        else if (id==R.layout.fragment_admin_frag){
            fragmentTransaction = fragmentManager.beginTransaction();
            Admin_frag frag_4 = new Admin_frag();
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.add(R.id.Main_layout,frag_4);
            fragmentTransaction.commit();

        }


    }


}










